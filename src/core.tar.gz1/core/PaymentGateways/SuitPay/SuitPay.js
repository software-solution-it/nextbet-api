const SelectTokenUser = require('../../../model/Mysq/SelectTokenUser/SelectTokenUser')
const SelectDepositGenerationID = require('../../../model/Mysq/Select/SelectDepositGenerationID/SelectDepositGenerationID')
const GetQrcodeSuitpay = require('../../../utils/axios/GetQrcodeSuitpay/GetQrcodeSuitpay')
const GetQrCodeDigitoPay = require('../../../utils/axios/GetQrCodeDigitoPay/GetQrCodeDigitoPay')
const UpdateMemberRecordTransactionIdSuitpay = require('../../../model/Mysq/Update/UpdateMemberRecordTransactionIdSuitpay/UpdateMemberRecordTransactionIdSuitpay')
const QRCode = require('qrcode');
require('dotenv').config()

async function generateQRCodeBase64(data) {
    try {
        const qrCodeBase64 = await QRCode.toDataURL(data);
        return qrCodeBase64; // Isso será uma string base64 que representa a imagem do QR Code
    } catch (error) {
        console.error("Erro ao gerar o QR Code:", error);
    }
}
async function Suitpay(token, code_buy, res) {
    let select_user_token = await SelectTokenUser(token)

    if (select_user_token) {

        let username = select_user_token.username


        let transaction_info = await SelectDepositGenerationID(code_buy.cbuy)


        if (transaction_info.username === username) {
            if (process.env.ACTIVE_PIXUP === 'true' | process.env.ACTIVE_BSPAY === 'true') {
                let url = "";
                let clientid = "";
                let clientsecret = "";

                if (process.env.ACTIVE_PIXUP === true) {
                    url = process.env.URL_PIXUP;
                    clientid = process.env.CLIENT_ID_PIXUP;
                    clientsecret = process.env.CLIENT_SECRET_PIXUP;
                } else {
                    url = process.env.URL_BSPAY;
                    clientid = process.env.CLIENT_ID_BSPAY;
                    clientsecret = process.env.CLIENT_SECRET_BSPAY;
                }

                let send_request_suitpay = await GetQrcodeSuitpay(url, clientid, clientsecret, '711.919.080-62', username, code_buy.cbuy, transaction_info.amount)
                const paymentcodebase64 = await generateQRCodeBase64(send_request_suitpay.qrcode);


                if (send_request_suitpay.status === "PENDING") {
                    let update_transaction_id_suitpay = await UpdateMemberRecordTransactionIdSuitpay(code_buy.cbuy, send_request_suitpay.transactionId)

                    if (update_transaction_id_suitpay === 1) {

                        res.json({ qrcode: send_request_suitpay.qrcode, qrcodeBase64: paymentcodebase64, amount: transaction_info.amount })
                    }
                    else {
                        res.json({ "status": false, "data": "Entre contato com suporte!", code: 500 })

                    }
                }
                else {
                    res.json({ "status": false, "data": "Entre contato com suporte!", code: 400 })
                }
            } else {
                let url = process.env.URL_DIGITO;
                let clientid = process.env.CLIENT_ID_DIGITO;
                let clientsecret = process.env.CLIENT_SECRET_DIGITO;

                let sendrequestdigitopay = await GetQrCodeDigitoPay(url, clientid, clientsecret, '711.919.080-62', username, code_buy.cbuy, transaction_info.amount)
                const paymentcodebase64 = await generateQRCodeBase64(send_request_suitpay.qrcode);


                if (sendrequestdigitopay.status === "PENDING") {
                    let update_transaction_id_suitpay = await UpdateMemberRecordTransactionIdSuitpay(code_buy.cbuy, sendrequestdigitopay.transactionId)

                    if (update_transaction_id_suitpay === 1) {

                        res.json({ qrcode: sendrequestdigitopay.qrcode, qrcodeBase64: paymentcodebase64, amount: transaction_info.amount })
                    }
                    else {
                        res.json({ "status": false, "data": "Entre contato com suporte!", code: 500 })

                    }
                }
                else {
                    res.json({ "status": false, "data": "Entre contato com suporte!", code: 400 })
                }
            }



        }
        else {
            res.json({ "status": false, "data": "Dados incorretos." })

        }

    }
    else {
        res.json({ "status": false, "data": "Não autenticado por favor faça login novamente." })
    }

}


module.exports = Suitpay