const SelectUser = require('../../model/Mysq/SelectUser/SelectUser')
const InsertUser = require('../../model/Mysq/InsertUser/InsertUser')
const hashPassword = require('../../utils/bcrypt/hashPassword/hashPassword')
const token_auth_Unique = require('../../utils/tokenAuth/tokenAuth')
const InsertPromotionInviteRecord = require('../../model/Mysq/Insert/InsertPromotionInviteRecord/InsertPromotionInviteRecord')
const baux = require('../../model/Mysq/Insert/InsertPromotionInviteRecord/bau')

function formatDateFromTimestamp(timestampInSeconds) {
  const date = new Date(timestampInSeconds * 1000);
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

async function Register(body, ip, timestampInSeconds, res) {
  let device_no = body.device_no;
  let username = body.username;
  let password = body.password;
  let repassword = body.repassword;
  let verify_code = body.verify_code;
  let code = body.code;
  let link_id = body.link_id;
  let reg_url = body.reg_url;

  let get_user_exist = await SelectUser(username, 'username');

  if (get_user_exist) {
    res.json({ "status": false, "data": "1062" });
  } else {
    let get_user_afiliate_exist = await SelectUser(link_id, 'id');
    let password_encrypt = await hashPassword(password);
    let token_unique = await token_auth_Unique();

    let formattedTimestamp = formatDateFromTimestamp(timestampInSeconds);

    let data_insert_user = {
      token_auth: token_unique,
      username: username,
      reg_device: device_no,
      password: password_encrypt,
      verify_code: verify_code,
      code: code,
      link_id: link_id,
      reg_url: reg_url,
      balance: 0,
      prefix: 'f90',
      birth: '',
      realname: '',
      email: '',
      phone: '',
      zalo: '',
      tester: '1',
      withdraw_pwd: 0,
      regip: ip,
      last_login_ip: formattedTimestamp,
      last_login_at: formattedTimestamp,
      source_id: 1,
      first_deposit_at: 0,
      first_deposit_amount: '0.00',
      first_bet_at: 0,
      first_bet_amount: '0.00',
      second_deposit_at: 0,
      second_deposit_amount: '0.00',
      top_uid: '4722355249852325',
      top_name: 'topga',
      parent_uid: get_user_afiliate_exist ? link_id : '',
      parent_name: get_user_afiliate_exist ? get_user_afiliate_exist.username : '',
      bankcard_total: 0,
      last_login_device: device_no,
      last_login_source: 24,
      remarks: "",
      state: 1,
      level: 0,
      lock_amount: '0.00',
      group_name: '1',
      agency_type: '391',
      address: '',
      avatar: '12',
      last_withdraw_at: '0',
      facebook: '',
      whatsapp: '',
      telegram: '',
      twitter: '',
      referer: '',
      device: '',
      fphone: '',
      total_dept_amount: '0.000',
      total_wdraw_amount: '0.000',
      link_black_list: 0,
      next: '1000.00',
      now: '0',
      rate: '0.00000',
      next_level: 1,
      rebate_amount: '',
      created_at: formattedTimestamp,
      updated_at: formattedTimestamp,
    };

    let insert_new_user = await InsertUser(data_insert_user);

    if (insert_new_user.status === 1) {
      if (get_user_afiliate_exist) {
        let data_insert_member_promotion_record = {
          owner_inviter_id: link_id,
          member_id: insert_new_user.id_insert,
          username: username,
          deposit_amount: 0,
          valid_bet_amount: 0,
          is_active: 1,
          created_at: formattedTimestamp,
        };
        await InsertPromotionInviteRecord(data_insert_member_promotion_record);
      }


      //   1-4
      let data_insert_promotion_invite_1 = {

        owner_username: username,
        bonus_amount: 10,
        mem_count: 1,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_1);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_2 = {

        owner_username: username,
        bonus_amount: 20,
        mem_count: 3,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_2);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_3 = {

        owner_username: username,
        bonus_amount: 20,
        mem_count: 5,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_3);


      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_4 = {

        owner_username: username,
        bonus_amount: 50,
        mem_count: 10,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_4);


      //   2-8
      let data_insert_promotion_invite_5 = {

        owner_username: username,
        bonus_amount: 50,
        mem_count: 30,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_5);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_6 = {

        owner_username: username,
        bonus_amount: 50,
        mem_count: 25,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_6);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_7 = {

        owner_username: username,
        bonus_amount: 50,
        mem_count: 20,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_7);


      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_8 = {

        owner_username: username,
        bonus_amount: 15,
        mem_count: 50,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_8);


      //   3-8
      let data_insert_promotion_invite_9 = {

        owner_username: username,
        bonus_amount: 100,
        mem_count: 40,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_9);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_10 = {

        owner_username: username,
        bonus_amount: 100,
        mem_count: 50,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_10);

      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_11 = {

        owner_username: username,
        bonus_amount: 100,
        mem_count: 60,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_11);


      // Insert second record into promotion_invite table
      let data_insert_promotion_invite_12 = {

        owner_username: username,
        bonus_amount: 100,
        mem_count: 70,
        sort: 1,
        state: 1
      };
      await baux(data_insert_promotion_invite_12);


      res.set('Id', 'f90:' + data_insert_user.token_auth);
      res.json({ "status": true, "data": "1000" });
    } else {
      res.json({ "status": false, "data": "Error insert User code 40002" });
    }
  }
}

module.exports = Register;