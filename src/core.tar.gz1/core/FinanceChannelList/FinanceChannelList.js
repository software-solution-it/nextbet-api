const SelectTokenUser = require('../../model/Mysq/SelectTokenUser/SelectTokenUser')
const SelectFinanceChannelType = require('../../model/Mysq/Select/SelectFInanceChannelType/SelectFInanceChannelType')
const SelectFinanceChannelList = require('../../model/Mysq/Select/SelectFinanceChannelList/SelectFinanceChannelList')
const SelectFinanceBonusList = require('../../model/Mysq/Select/SelectFinanceChannelBonusList/SelectFinanceChannelBonusList')
async function FinanceChannelList(token, body,res)
{

    let select_user_token = await SelectTokenUser(token)

    if (select_user_token) {
        
        const channel_type = parseInt(body.channel_type)

        const select_finance_channel_type = await SelectFinanceChannelType(1,channel_type)

        if (select_finance_channel_type) {
            const select_finance_channel_list = await SelectFinanceChannelList(channel_type)


            console.log(select_user_token.first_deposit_amount > 0)
            if (select_user_token.first_deposit_amount > 0) {
                const select_finance_bonus_list = await SelectFinanceBonusList();

               
                const updated_select_finance_bonus_list = select_finance_bonus_list.map(item => {
                    return {
                        ...item,
                        bonus_amount: 0
                    };
                });
                
                select_finance_channel_list.forEach(item => {
                    item.bonus_list = updated_select_finance_bonus_list;
                });
                
                let finance_channel_type_response = {
                    "status": true,
                    "data": select_finance_channel_list
                };
 
                res.json(finance_channel_type_response) 
            }
            else
            {
                const select_finance_bonus_list = await SelectFinanceBonusList()

            
                select_finance_channel_list.forEach(item => {
                    item.bonus_list = select_finance_bonus_list;
                });
                let finance_channel_type_response ={
                    "status": true,
                    "data": select_finance_channel_list
                }
        
    
                
                // let obj_channel_list =           {
                //     "id": "1600",
                //     "factory_id": "30",
                //     "channel_type_id": "8",
                //     "show_name": "Owen",
                //     "fmin": 10,
                //     "fmax": 50000,
                //     "amount_list": "20,30,50,100,500,1000,5000,10000,30000,50000",
                //     "state": "1",
                //     "sort": 2,
                //     "comment": "owen代收",
                //     "vip_list": "1,2,3,4,5,6,7,8,9,10",
                //     "discount": "0.00",
                //     "created_at": 1,
                //     "updated_at": 1719517720,
                //     "is_zone": 1,
                //     "is_fast": 1,
                //     "is_rang": 1,
                //     "web_img": "1",
                //     "h5_img": "1",
                //     "app_img": "1",
                //     "daily_max_amount": 9999999,
                //     "daily_finish_amount": 0,
                //     "flag": 1,
                //     "third_code": "BRL002",
                //     "factory_name": "",
                //     "bonus_list": select_finance_bonus_list,
                //     "balance": "",
                //     "grade_list": "2027,2026,2025,1009,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,1001,1002,1003,1004,1005,1006,1007,1008,2024,2028",
                //     "list": "[{\"min\": 0, \"flag\": 1, \"rate\": \"\", \"level\": \"\", \"tagsArr\": []}]",
                //     "crowd": 0,
                //     "deposit": 0
                // },
    
         
                res.json(finance_channel_type_response)
            }
     
        }
     
    }
    else
    {

        res.json({"status":false,"data":"Não Autenticado"}
        )
    }

}

module.exports = FinanceChannelList